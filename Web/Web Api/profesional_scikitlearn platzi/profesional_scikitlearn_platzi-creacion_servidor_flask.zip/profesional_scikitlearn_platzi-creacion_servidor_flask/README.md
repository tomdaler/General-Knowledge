# profesional_scikitlearn_platzi
Repositorio de código usado durante el Curso Profesional de Scikit-Learn para Platzi.

En este repositorio podrás encontrar 16 ramas relacionadas con el curso, en orden:

1. preparacion_datos_pca
2. implementacion_algoritmo_pca
3. kernel_y_pca
4. implementacion_lasso_ridge 
5. preparacion_regresion_robusta
6. implementacion_regresion_robusta
7. preparacion_datos_bagging
8. implementacion_bagging
9. implementacion_boosting
10. implementacion_kmeans
11. implementacion_meanshift
12. implementacion_crossval
13. implementacion_randomizedSearchCV
14. revision_arquitectura
15. creacion_exportacion_modelo
16. creacion_servidor_flask
